#include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 typedef struct { int id; int x; int y; 
} Node; 
double distance(Node a, Node b) {
 return sqrt(pow(a.x - b.x, 2) + pow(a.y - b.y, 2)); 
} 
int main(int argc, char *argv[]) {
 if (argc != 3) {
 	printf("Usage: %s <diameter> <range>\n", argv[0]);
 	return 1; 
} 
 int D = atoi(argv[1]);
 double range = atof(argv[2]);
int num_nodes = D * D;
 Node nodes[num_nodes];
 for (int i = 0; i < num_nodes; i++) {
 	nodes[i].id = i; 
 	nodes[i].x = i / D;
	nodes[i].y = i % D; 
 } 
 FILE *file = fopen("topology.txt", "w");
 if (file == NULL) { perror("Error opening file");
 return 1;
 } 
for (int i = 0; i < num_nodes; i++) {
 	for (int j = 0; j < num_nodes; j++) {
 		if (i != j && distance(nodes[i], nodes[j]) <= range) {
 			fprintf(file, "%d %d -50 \n",nodes[i].id,nodes[j].id);
		 }
 	} 
fprintf(file, "\n");
 }
 fclose(file);
 printf("Topology file created as 'topology.txt'.\n");
 return 0; 
}












