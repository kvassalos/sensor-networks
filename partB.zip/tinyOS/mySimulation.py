#!/usr/bin/python

from TOSSIM import *
import sys ,os
import random
import subprocess


D=int(sys.argv[1]);
dimensions=D*D;
scope= float(sys.argv[2]);
file_name=sys.argv[3]

t=Tossim([])
f=sys.stdout #open('./logfile.txt','w')
SIM_END_TIME= 600 * t.ticksPerSecond()

print "TicksPerSecond : ", t.ticksPerSecond(),"\n"

t.addChannel("Boot",f)
t.addChannel("RoutingMsg",f)
t.addChannel("NotifyParentMsg",f)
t.addChannel("Radio",f)
#t.addChannel("Serial",f)
t.addChannel("SRTreeC",f)
#t.addChannel("PacketQueueC",f)


try : 
	compilation=subprocess.call(['gcc','helper.c','-o','helper','-lm'])
	if compilation!=0 :
		print("Compilation failed!")
		sys.exit(1)
	print("Compilation Succesful!")
except OSError as e: 
	print("Compilation failed: {e}")
	sys.exit(1)

try: 
	execution=subprocess.Popen(
	['./helper',str(D),str(scope)],
	stdout=subprocess.PIPE,
	stderr=subprocess.PIPE
)
	stdout,stderr=execution.communicate()

	if(execution.returncode!=0):
		print("Execution failed:{stderr.decode()}")
except OSError as e: 
	print("Compilation failed: {e}")

	
for i in range(0,dimensions):
	m=t.getNode(i)
	m.bootAtTime(dimensions*t.ticksPerSecond() + i)


topo = open(file_name, "r")

if topo is None:
	print "Topology file not opened!!! \n"


	
r=t.radio()
lines = topo.readlines()
for line in lines:
  s = line.split()
  if (len(s) > 0):
    print " ", s[0], " ", s[1], " ", s[2];
    r.add(int(s[0]), int(s[1]), float(s[2]))

mTosdir = os.getenv("TINYOS_ROOT_DIR")
noiseF=open(mTosdir+"/tos/lib/tossim/noise/meyer-heavy.txt","r")
lines= noiseF.readlines()

for line in  lines:
	str1=line.strip()
	if str1:
		val=int(str1)
		for i in range(0,dimensions):
			t.getNode(i).addNoiseTraceReading(val)
noiseF.close()
for i in range(0,dimensions):
	t.getNode(i).createNoiseModel()
	
ok=False
#if(t.getNode(0).isOn()==True):
#	ok=True
h=True
while(h):
	try:
		h=t.runNextEvent()
		#print h
	except:
		print sys.exc_info()
#		e.print_stack_trace()

	if (t.time()>= SIM_END_TIME):
		h=False
	if(h<=0):
		ok=False

